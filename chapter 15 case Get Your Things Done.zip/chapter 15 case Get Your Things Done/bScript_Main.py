# Code Get Your Things Done
# @author: Benjamin M. Abdel-Karim
# @since: 2020-06-28
# @version: 1.0
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('report.csv', sep=',')
print(df.columns.tolist())
print(df.shape)

# ------------------------------
# ------- Pre-processing -------
# ------------------------------
# Alle unnoetigen Zeilen entfernen.
df = df.drop(['TimeEntryID', 'ActivityID', 'SpaceId', 'Space',
              'Username', 'Note', 'Mentions', 'Tags'], axis=1)

# Uebersicht ueber das aktualisierte DataFrame.
print(df.info())

# Umwandung von Zeilenwerten in datetime format.
df['StartDate'] = pd.to_datetime(df['StartDate'])
df['StartDate'] = pd.to_datetime(df['StartDate'], format='%d/%m/%Y')

df['StartTime'] = pd.to_datetime(df['StartTime'])
df['StartTime'] = pd.to_datetime(df['StartTime'], format='%H:%M:%S').dt.time

df['EndDate'] = pd.to_datetime(df['EndDate'])
df['EndDate'] = pd.to_datetime(df['EndDate'], format='%d/%m/%Y')

df['EndTime'] = pd.to_datetime(df['EndTime'])
df['EndTime'] = pd.to_datetime(df['EndTime'], format='%H:%M:%S').dt.time

df['Duration'] = pd.to_timedelta(df['Duration'])

# --------------------------------
# ------- Explore the data -------
# --------------------------------
# Ausgabe der unterschiedlichen Aktivitaeten
LActivity = df['Activity'].unique().tolist()
print(LActivity)

# Deskriptive Statistik
print(df['Duration'].describe())

# Datentransformation von datetime zu Int Werten
df['Duration_seconds'] = pd.to_timedelta(df['Duration']).dt.total_seconds().astype(int)
df['Duration_minutes'] = df['Duration_seconds'] /60.0

# Boxplot fuer die Aufgaben und ihren Zeitanspruch
fig, ax = plt.subplots()
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.yaxis.set_ticks_position('left')
ax.xaxis.set_ticks_position('bottom')
ax = sns.boxplot(x="Activity", y="Duration_minutes", data=df,
                 palette='Greys', order=sorted(LActivity))
plt.xticks(rotation=45, fontsize=6)
plt.xlabel('Aufgaben')
plt.ylabel('Zeit in Minuten')
plt.tight_layout()
plt.savefig('2_Activity_Boxplot.pdf')
plt.show()

# Bestimme den Anteil der Aktivitaeten
# Fuer eine Kategorie.
dfAdministrative = df.loc[df['Activity'] == 'Administrative']
iAdministrativeInMin = dfAdministrative['Duration_minutes'].sum()

# Kompakte Variante fuer alle Aktivitaeten
dfActivityMin = df.groupby('Activity')['Duration_minutes'].sum()

# Pie chart
# @source: https://medium.com/@kvnamipara/a-better-visualisation-of-pie-charts-by-matplotlib-935b7667d77f
LLabels = dfActivityMin.index
LSizes = dfActivityMin.tolist()

# colors
LColors = ['#DCDCDC', '#D3D3D3', '#C0C0C0', '#A9A9A9',
           '#808080', '#696969', '#BCBCBC', '#E0E0E0']

# Pie Plot
fig, ax = plt.subplots()
ax.pie(LSizes, colors=LColors, labels=LLabels, autopct='%1.1f%%', startangle=90)

# Lege weissen Ring ueber den Pie Plot. Fuer modernes Layout.
centre_circle = plt.Circle((0, 0), 0.70, fc='white')
fig = plt.gcf()
fig.gca().add_artist(centre_circle)

# Sicherstellen des gleichen Seitenverhaeltnisses zwischen
# Pie Plot und der weissen Abdeckung.
ax.axis('equal')
plt.tight_layout()
plt.savefig('3_Activity_Plot.pdf')
plt.show()

# Find abrechenbare Stunden mit Hilfe binarer codierung
df.loc[df['Activity'] == 'Administrative', 'type'] = 0
df.loc[df['Activity'] == 'Consulting', 'type'] = 1
df.loc[df['Activity'] == 'Development', 'type'] = 1
df.loc[df['Activity'] == 'Design', 'type'] = 1
df.loc[df['Activity'] == 'Feedback', 'type'] = 0
df.loc[df['Activity'] == 'Learning', 'type'] = 0
df.loc[df['Activity'] == 'Lunch', 'type'] = 0
df.loc[df['Activity'] == 'Meetings', 'type'] = 0

print(df['type'].value_counts())

# Berechnung der abrechenbaren Stunden
df['Price'] = df['Duration_minutes'] * (1000/60)

# Groupby operation mit Bedingung
dfPrice = df[df['type'] == 1].groupby('Activity')['Price'].sum()
dfPrice.to_latex('GesamtsummeAbrechenbar.tex')

# Summiere einen Preis
dPrice = df['Price'][df['type'] == 1].sum()

# --------------------------------
# ------- Model -------
# --------------------------------
# Datenvorbereitung fuer das Modell mit One Hot Endcoding
df['Duration_h'] = df['Duration_minutes']/60

# Unterschiede in der Skalierung
fig, ax = plt.subplots(2, figsize=(7,7))
sns.distplot(df['Duration_minutes'], color='darkgray',
             hist_kws=dict(edgecolor='k', linewidth=0.5), ax=ax[0])
sns.distplot(df['Duration_h'], color='k',
             hist_kws=dict(edgecolor='w', linewidth=0.5), ax=ax[1])
# Entfernung der Raender
ax[0].spines['right'].set_visible(False)
ax[0].spines['top'].set_visible(False)
ax[0].yaxis.set_ticks_position('left')
ax[0].xaxis.set_ticks_position('bottom')
ax[1].spines['right'].set_visible(False)
ax[1].spines['top'].set_visible(False)
ax[1].yaxis.set_ticks_position('left')
ax[1].xaxis.set_ticks_position('bottom')
plt.savefig('4_Distribution.pdf')
plt.show()

# One Hot Endcoding
dfDummies = pd.get_dummies(df['Activity'])
X = dfDummies.to_numpy()
y = df['Duration_h'].to_numpy()  # Try later: 'Duration_minutes'
y = y.astype('int')

# Notwendige Pakete. Aus didaktischen Gruenden hier.
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn import metrics
# Datenaufteilung in Train und Test.
X_train, X_test, y_train, y_test = \
    train_test_split(X, y, test_size=0.33)

# --------------
# Create model
# --------------
# Einfaches Perceptron
model = Perceptron()

# --------------
# Create train
# --------------
model.fit(X_train, y_train)

# --------------
# Evaluate model
# --------------
y_pred = model.predict(X_test)

# Accuracy:
dAccuracy = metrics.accuracy_score(y_test, y_test)
print("Accuracy:", metrics.accuracy_score(y_test, y_pred))

print('done')