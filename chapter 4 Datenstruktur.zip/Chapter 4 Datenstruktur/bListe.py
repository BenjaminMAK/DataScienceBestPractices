# Die Verwendung von Listen in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

# Eine Liste erstellen.
LNames = []

# Einen Namen in die Namensliste aufnehmen.
LNames.append('Julia')

# Zugriff auf das erste Element der Liste, um an den Namen zu gelangen.
sFirstNameFromList = LNames[0]
print(sFirstNameFromList)

# Die Listen in der Liste
LPerson = [['Lisa', 'Max', 'Marlene']]
print(LPerson[0][0])

