# Die Verwendung von Listen als Stack in Queue
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1
# Ein neuer Stack wird angelegt.
LQueue = []

# Drei neue Rechnungen kommen hinzu.
LQueue.append('Rechnung_1')
LQueue.append('Rechnung_2')
LQueue.append('Rechnung_3')
print(LQueue)

# Die letzte Rechnung soll entfernt werden.
LQueue.remove(LQueue[0])

print(LQueue)