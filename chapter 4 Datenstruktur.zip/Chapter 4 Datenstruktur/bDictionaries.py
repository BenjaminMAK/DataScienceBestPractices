# Die Verwendung von Dictionaries in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

# Anlegen eines Dictionary.
Dic = {'vorname': 'Lisa', 'nachname': 'Mustermann', 'alter': 25, 'weiblich': True}

# Zugriff auf einen Wert ueber den Schluessel
sVorname = Dic.get('vorname')
print(sVorname)

sAlter = Dic.get('Alter')
print(sAlter)

# Weitere Werte hinzufuegen
Dic.update({'Einkommen': 1000})

sKeys = Dic.keys()
print(sKeys)