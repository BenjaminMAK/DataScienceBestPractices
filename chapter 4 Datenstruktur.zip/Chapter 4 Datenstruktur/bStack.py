# Die Verwendung von Listen als Stack in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

# Ein neuer Stack wird angelegt.
LStack = []

# Drei neue Rechnungen kommen hinzu.
LStack.append('Rechnung_1')
LStack.append('Rechnung_2')
LStack.append('Rechnung_3')
print(LStack)

# Die oberste Rechnung wird aus dem Stack genommen.
LStack.pop()
print(LStack)