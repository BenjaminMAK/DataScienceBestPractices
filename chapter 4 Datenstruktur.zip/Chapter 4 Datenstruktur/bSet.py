# Die Verwendung von Listen in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

# Zwei Sets erstellen.
SA = set('ABCD')
SB = set('DEFG')

# Alle Elemente aus A ausgeben lassen
print(SA)

# Alle Elemente, die in A oder B zu finden sind.
print(SA ^ SB)

# Alle Elemente finden, die in A und nicht in B sind.
print(SA-SB)

# Alle Elemente, die in A oder B zu finden sind.
print(SA | SB)

# Alle Elemente finden, die sowohl in A als auch in B sind.
print(SA & SB)



