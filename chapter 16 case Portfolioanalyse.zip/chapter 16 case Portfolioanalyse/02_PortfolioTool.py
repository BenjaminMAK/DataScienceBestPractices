# Code Portfolioanalyse
# @author: Marcel Zeuch
# @since: 2020-06-30
# @version: 1.0

# Importierung von dash und zugehoeriger Komponenten
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output
import dash_html_components as html
import dash_table

# Importierung weiterer Bibliotheken zur Portfolioanalyse
from datetime import datetime
import mysql.connector
import pandas as pd
import plotly.graph_objects as go

# Initialisierung der Verbindung zur MySQL-Datenbank
connection = mysql.connector.connect(host=HOST,
                                     database='data_science',
                                     user=USERNAME,
                                     password=PASSWORT)

cursor = connection.cursor()

# Abfrage an die Datenbank: Ausgabe des aktuellen Portfolios. Speicherung im DataFrame 'df_portfolio'
sql_select = """select * from
             (select s.id, s.ticker, s.name, s.isin, min(p.trade_date) as 'invested_since', 
             LEFT(isin,2) as 'country', s.industry, null,
             round((select m.close from marketdata_daily m where m.security_id = p.security_id
             order by m.date desc limit 1),2) as 'portfolio_value',
             sum(if(p.trade_direction=1,1,-1)*p.nominal) as 'nominal_sum'
             from portfolio_transactions p
             join statics s on s.id = p.security_id
             where s.ticker is not null
             group by p.security_id) cp
             where cp.nominal_sum > 0"""
cursor.execute(sql_select)
df_portfolio = pd.DataFrame(cursor.fetchall())

# Entsprechende Benennung der Spalten des DataFrames
df_portfolio.columns = ['security_id', 'Ticker', 'Name', 'ISIN', 'Erstinvestition', 'Land', 'Industrie',
                        'Portfoliobestand (in %)', 'Portfolioentwicklung (in %)', 'Summe Nominal']

# Abfrage an die Datenbank: Aktueller Gesamtwert des Portfolios. Speicherung in der Variablen 'portfolio_value'
sql_select = """select sum(portfolio_value) from
             (select (sum(if(p.trade_direction=1,1,-1)*p.nominal))*
             (select round(if(s.currency='USD',m.close/mf.close,m.close),2) from marketdata_daily m 
             join marketdata_fx_daily mf on mf.date=m.date 
             where m.security_id = p.security_id order by m.date desc limit 1) as 'portfolio_value'
             from portfolio_transactions p
             join statics s on s.id = p.security_id
             where s.ticker is not null
             group by p.security_id) pv"""
cursor.execute(sql_select)
portfolio_value = cursor.fetchone()[0]

# Abfrage an die Datenbank: Sortierung des Portfolios nach Land. Speicherung im DataFrame 'df_country'
sql_select = """select cp.country, sum(cp.portfolio_value) as 'total_portfolio_value' from
             (select s.name, s.isin, min(p.trade_date) as 'invested since', LEFT(isin,2) as 'country', s.industry,
             (sum(if(p.trade_direction=1,1,-1)*p.nominal))*
             (select round(if(s.currency='USD',m.close/mf.close,m.close),2) from marketdata_daily m 
             join marketdata_fx_daily mf on mf.date=m.date 
             where m.security_id = p.security_id order by m.date desc limit 1) as 'portfolio_value',
             sum(if(p.trade_direction=1,1,-1)*p.nominal) as 'nominal_sum'
             from portfolio_transactions p
             join statics s on s.id = p.security_id
             where s.ticker is not null
             group by p.security_id) cp
             where cp.nominal_sum > 0
             group by cp.country
             order by total_portfolio_value desc
             limit 5"""
cursor.execute(sql_select)
df_country = pd.DataFrame(cursor.fetchall())

# Gegebenenfalls Hinzufuegen fehlender Laender und dessen ausmachender Portfoliowert
if len(df_country) != len(df_portfolio.groupby('Land')):

    csum = pd.DataFrame({0: ['Weitere'], 1: [round(portfolio_value - df_country[1].sum(), 2)]}, index=[5])
    df_country = pd.concat([df_country, csum])

# Abfrage an die Datenbank: Sortierung des Portfolios nach Industrie. Speicherung im DataFrame 'df_industry'
sql_select = """select cp.industry, sum(cp.portfolio_value) as 'total_portfolio_value' from
             (select s.name, s.isin, min(p.trade_date) as 'invested since', LEFT(isin,2) as 'country', s.industry,
             (sum(if(p.trade_direction=1,1,-1)*p.nominal))*
             (select round(if(s.currency='USD',m.close/mf.close,m.close),2) from marketdata_daily m 
             join marketdata_fx_daily mf on mf.date=m.date 
             where m.security_id = p.security_id order by m.date desc limit 1) as 'portfolio_value',
             sum(if(p.trade_direction=1,1,-1)*p.nominal) as 'nominal_sum'
             from portfolio_transactions p
             join statics s on s.id = p.security_id
             where s.ticker is not null
             group by p.security_id) cp
             where cp.nominal_sum > 0
             and cp.industry is not null
             group by cp.industry
             order by total_portfolio_value desc
             limit 5"""
cursor.execute(sql_select)
df_industry = pd.DataFrame(cursor.fetchall())

# Gegebenenfalls Hinzufuegen fehlender Industrien und dessen ausmachender Portfoliowert
if len(df_country) != len(df_portfolio.groupby('Industrie')):

    isum = pd.DataFrame({0: ['Weitere'], 1: [round(portfolio_value-df_industry[1].sum(), 2)]}, index=[5])
    df_industry = pd.concat([df_industry, isum])

# Abfrage an die Datenbank: Ausgabe aller Portfoliotransaktionen mit entsprechend kumuliertem Nominal.
# Speicherung im DataFrame 'df_return'
sql_select = """select p1.security_id, p1.trade_date, p1.trade_direction, p1.nominal, p1.trade_price,
             (select sum(if(p0.trade_direction=1,1,-1)*p0.nominal) from portfolio_transactions p0
             where p0.security_id=p1.security_id and p0.trade_date<=p1.trade_date) as 'cumulative_nominal'
             from portfolio_transactions p1"""
cursor.execute(sql_select)
df_return = pd.DataFrame(cursor.fetchall())

# Entsprechende Benennung der Spalten des DataFrames
df_return.columns = ['security_id', 'trade_date', 'trade_direction', 'nominal', 'trade_price', 'cumulative_nominal']

# Speicherung des kumulierten Nominals als Zahl, um Rechenoperationen hiermit ausfuehren zu koennen
df_return['cumulative_nominal'] = pd.to_numeric(df_return['cumulative_nominal'])

# Abfrage an die Datenbank: Ausgabe aller security ID's, die jemals gehandelt worden. Speicherung im
# DataFrame 'df_sec'
sql_select = """select security_id, null from portfolio_transactions group by security_id"""
cursor.execute(sql_select)
df_sec = pd.DataFrame(cursor.fetchall())

# Entsprechende Benennung der Spalten des DataFrames
df_sec.columns = ['security_id', 'cumulative_price']

# Initialisierung der Liste 'var', in Anlehnung an das Wort 'variabel'. Jeder Listeneintrag wird spaeter
# Marktdateninformationen zu einer security ID beinhalten
var = [[]]*(max(df_sec['security_id'])+1)

# Initialisierung der Liste 'initial_date'. Jeder Listeneintrag wird spaeter jeweils den Handelstag der Erstinvestition
# einer security ID beinhalten
initial_date = [[]]*(max(df_sec['security_id'])+1)

# Berechnung der historischen Portfolioentwicklung. Durchfuehrung der Iteration nach security ID
for i in range(0, len(df_sec)):

    # Speicherung der jeweils zu iterierenden security ID in der Variablen 'sec_id'
    sec_id = df_sec.loc[i, 'security_id']

    # Erstellung eines temporaeren DataFrames 'dff'. Dieser entspricht dem DataFrame 'df_return' restringiert auf die
    # jeweils zu iterierende security ID 'sec_id'
    dff = df_return[df_return['security_id'] == sec_id]

    # Speicherung der Indexwerte des DataFrames 'dff' in der Variablen 'index'
    index = list(dff.index.values)

    # Speicherung des Handelstages der Erstinvestition der jeweils zu iterierenden security ID 'sec_id'
    initial_date[sec_id] = str(df_return.loc[min(index), 'trade_date'])

    # Berechnung des kumulierten Portfoliowertes zu jedem Handelstag der jeweils zu iterierenden securtiy ID 'sec_id'.
    # Durchfuehrung der Iteration nach Handelstag
    for j in range(0, len(dff)):

        # Erster Fall (Initialisierung): Handelstag der Erstinvestition
        if index[j] == min(index):

            # Speicherung des kumulierten Handelspreis der zugehoerigen, zu iterierenden security ID 'sec_id' im
            # DataFrame 'df_sec'. Am Handelstag der Erstinvestition entspricht der kumulierte Handelspreis dem
            # Kaufpreis
            df_sec.loc[i, 'cumulative_price'] = df_return.loc[index[j], 'trade_price']

            # Abfrage an die Datenbank: Bereitstellung der Marktdaten der zu iterierenden security ID 'sec_id'
            # ab dem ersten Handelstag, zuzueglich der zugehoerigen taeglichen FX Wechselkurse. Speicherung im
            # DataFrame 'df_market'
            sql_select = """select m.date, m.security_id, m.close, if(s.currency='EUR',1,mf.close), 
                        null, null from marketdata_daily m
                        left join marketdata_fx_daily mf on mf.date = m.date
                        left join statics s on s.id = m.security_id
                        where m.security_id = """ + str(df_sec.loc[i, 'security_id']) + \
                         " and m.date >= '" + str(initial_date[sec_id]) + """'
                        order by date desc"""
            cursor.execute(sql_select)
            df_market = pd.DataFrame(cursor.fetchall())

            # Entsprechende Benennung der Spalten des DataFrames
            df_market.columns = ['date', 'security_id', 'close', 'fx_close', 'portfolio_value', 'initial_value']

            # Initialisierung und Berechnung des Portfoliowertes, vom ersten bis zum naechsten Handelstag.
            # Speicherung im DataFrame 'df_market'
            df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                          (df_market['date'] < df_return.loc[index[j+1], 'trade_date']), 'portfolio_value'] = \
                df_market['close'] / df_market['fx_close'] * \
                df_return.loc[index[j], 'cumulative_nominal']

            # Initialisierung und Berechnung des originalen Portfoliowertes, vom ersten bis zum naechsten Handelstag.
            # Speicherung im DataFrame 'df_market'
            df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                          (df_market['date'] < df_return.loc[index[j + 1], 'trade_date']), 'initial_value'] = \
                df_sec.loc[i, 'cumulative_price'] / df_market['fx_close'] * \
                df_return.loc[index[j], 'cumulative_nominal']

        # Zweiter Fall: Handelstage, an denen ein Kauf der zu iterierenden security stattgefunden hat
        elif dff.loc[index[j], 'trade_direction'] == 1:

            # Aktualisierung des kumulierten Handelspreises. Speicherung im DataFrame 'df_sec'
            df_sec.loc[i, 'cumulative_price'] = \
                (df_return.loc[index[j], 'nominal'] * df_return.loc[index[j], 'trade_price'] +
                 df_return.loc[index[j-1], 'cumulative_nominal'] * df_sec.loc[i, 'cumulative_price']) / \
                (df_return.loc[index[j], 'nominal'] + df_return.loc[index[j-1], 'cumulative_nominal'])

            # Unterscheidung, ob es sich um den letzten Handelstag der zu iterierenden security handelt
            if index[j] == max(index):

                # Berechnung des Portfoliowertes ab dem letzten Handelstag bis zum aktuellen Datum
                df_market.loc[df_market['date'] >= df_return.loc[index[j], 'trade_date'],
                              'portfolio_value'] = \
                    df_market['close'] / df_market['fx_close'] * df_return.loc[index[j], 'cumulative_nominal']

                # Berechnung des originalen Portfoliowertes ab dem letzten Handelstag bis zum aktuellen Datum
                df_market.loc[df_market['date'] >= df_return.loc[index[j], 'trade_date'], 'initial_value'] = \
                    df_sec.loc[i, 'cumulative_price'] / df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

            else:

                # Berechnung des Portfoliowertes bis zum naechsten Handelstag
                df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                              (df_market['date'] < df_return.loc[index[j+1], 'trade_date']), 'portfolio_value'] = \
                    df_market['close']/df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

                # Berechnung des originalen Portfoliowertes bis zum naechsten Handelstag
                df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                              (df_market['date'] < df_return.loc[index[j + 1], 'trade_date']), 'initial_value'] = \
                    df_sec.loc[i, 'cumulative_price'] / df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

        # Dritter Fall: Handelstage, an denen ein Verkauf der zu iterierenden security stattgefunden hat.
        # In diesem Fall aendert sich der kumulierte Handelspreis nicht
        elif dff.loc[index[j], 'trade_direction'] == 0:

            # Unterscheidung, ob es sich um den letzten Handelstag der zu iterierenden security handelt
            if index[j] == max(index):

                # Berechnung des Portfoliowertes ab dem letzten Handelstag bis zum aktuellen Datum
                df_market.loc[df_market['date'] >= df_return.loc[index[j], 'trade_date'],
                              'portfolio_value'] = \
                    df_market['close'] / df_market['fx_close'] * df_return.loc[index[j], 'cumulative_nominal']

                # Berechnung des originalen Portfoliowertes ab dem letzten Handelstag bis zum aktuellen Datum
                df_market.loc[df_market['date'] >= df_return.loc[index[j], 'trade_date'], 'initial_value'] = \
                    df_sec.loc[i, 'cumulative_price'] / df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

            else:

                # Berechnung des Portfoliowertes bis zum naechsten Handelstag
                df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                              (df_market['date'] < df_return.loc[index[j+1], 'trade_date']), 'portfolio_value'] = \
                    df_market['close'] / df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

                # Berechnung des originalen Portfoliowertes bis zum naechsten Handelstag
                df_market.loc[(df_market['date'] >= df_return.loc[index[j], 'trade_date']) &
                              (df_market['date'] < df_return.loc[index[j + 1], 'trade_date']), 'initial_value'] = \
                    df_sec.loc[i, 'cumulative_price'] / df_market['fx_close'] * \
                    df_return.loc[index[j], 'cumulative_nominal']

    # Unterscheidung, ob die aktuell zu iterierende security ID im aktuellen Portfolio liegt
    try:
        # Bestimmung des aktuellen Portfoliobestands (in %) der zu iterierenden security 'sec_id'. Speicherung im
        # DataFrame 'df_portfolio'
        df_portfolio.loc[df_portfolio['security_id'] == sec_id, 'Portfoliobestand (in %)'] = \
            round(df_market.loc[0, 'portfolio_value'] / portfolio_value * 100, 2)

        # Bestimmung der Portfolioentwicklung seit Erstinvestition (in %) der zu iterierenden
        # security 'sec_id'. Speicherung im DataFrame 'df_portfolio'
        df_portfolio.loc[df_portfolio['security_id'] == sec_id, 'Portfolioentwicklung (in %)'] = \
            round((df_portfolio.loc[df_portfolio['security_id'] == sec_id, 'Portfolioentwicklung (in %)'] /
                   df_sec.loc[i, 'cumulative_price']-1) * 100, 2)
    except:
        pass

    # Fallunterscheidung nach zu iterierender security ID. Initialisierung und Speicherung der berechneten
    # Portfoliowerte in der Liste 'var' und dem DataFrame 'df_dash'
    if i == 0:

        var[sec_id] = df_market[['date', 'portfolio_value', 'initial_value']]
        df_dash = df_market[['date', 'portfolio_value', 'initial_value']]

    else:

        # Speicherung der berechneten Portfoliowerte in der Liste 'var' und dem DataFrame 'df_dash'. Dieser wird
        # iterativ erweitert
        var[sec_id] = df_market[['date', 'portfolio_value', 'initial_value']]
        df_dash = pd.concat([df_dash, df_market[['date', 'portfolio_value', 'initial_value']]])

# Gruppierung des DataFrames 'df_dash' nach Datum. Die gespeicherten Portfoliowerte werden fuer jedes Datum summiert
df_dash = df_dash.groupby('date').sum()

# Speicherung der Laender und deren zugehoeriger Portfoliowerte in den Variablen 'clabels' und 'cvalues'
clabels = df_country[0]
cvalues = df_country[1]

# Speicherung der Industrien und deren zugehoeriger Portfoliowerte in den Variablen 'ilabels' und 'ivalues'
ilabels = df_industry[0]
ivalues = df_industry[1]

# Festsetzung eines harmonisierten Farbschemas in Form der Liste 'colors'
colors = ['#E0E0E0', '#BCBCBC', '#696969', '#808080', '#A9A9A9', '#C0C0C0']

# Erstellung eines Ringdiagrammes zur Darstellung der geografischen Portfolioverteilung
fig_country = go.Figure(data=[go.Pie(labels=clabels, values=cvalues, hole=.5, marker_colors=colors, name='Laender')])
fig_country.update_traces(hoverinfo='label+value+percent+name', textinfo='none')

# Erstellung eines Ringdiagrammes zur Darstellung der Portfolioverteilung nach Industrie
fig_industry = go.Figure(data=[go.Pie(labels=ilabels, values=ivalues, hole=.5, marker_colors=colors, name='Industrie')])
fig_industry.update_traces(hoverinfo='label+value+percent+name', textinfo='none')

# Erstellung des DataFrames 'df_table_pf', welcher die aktuellen Portfoliopositionen in einer Tabelle abbildet
df_table_pf = df_portfolio[['security_id', 'Name', 'Erstinvestition', 'Land', 'Industrie',
                           'Portfoliobestand (in %)', 'Portfolioentwicklung (in %)']]

# Initialisierung der Applikation in Dash. Speicherung externer Grafik- und Darstellungselemente in CSS
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

server = app.server

# Festlegung des App-Layouts und Defnition der Inhalte
app.layout = html.Div(
    [
        html.Div(
            [
                html.Div(
                    [
                        html.H1("Portfolioanalyse", className="app__header__title",
                                style={'textAlign': 'center', 'color': '#FFFFFF'}),
                        html.P(
                            "By Marcel Zeuch, 2020",
                            className="app__header__title--grey",
                            style={'textAlign': 'center', 'color': '#FFFFFF'},
                        ),
                    ],
                    className="app__header__desc",
                ),
            ],
            className="app__header",
        ),
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                html.Div(
                                    [html.H5("Portfoliouebersicht und Wertentwicklung", className="graph__title",
                                             style={'textAlign': 'center', 'backgroundColor': '#EFEFEF'})],
                                ),
                                dcc.Graph(
                                    id='portfolio'
                                ),
                                html.Div(id='graph-container')
                            ],
                            className="graph__container",
                        ),
                        html.Div(
                            [
                                dash_table.DataTable(
                                    id='datatable-row-ids',
                                    columns=[
                                        {'name': i, 'id': i, 'selectable': True} for i in df_table_pf.columns
                                    ],
                                    data=df_table_pf.to_dict('records'),
                                    sort_action='native',
                                    sort_mode='multi',
                                    row_selectable='multi',
                                ),
                                html.Div(id='datatable-row-ids-container')
                            ],
                            className="graph__container",
                        ),
                    ],
                    className="two-thirds column portfolio__container",
                ),
                html.Div(
                    [
                        html.Div(
                            [
                                html.Div(
                                    [
                                        html.H5(
                                            "Geografische Portfolioverteilung",
                                            className="graph__title",
                                            style={'textAlign': 'center', 'backgroundColor': '#EFEFEF'}
                                        )
                                    ]
                                ),
                                dcc.Graph(
                                    id='country',
                                    figure=fig_country
                                ),
                            ],
                            className="graph__container first",
                        ),
                        html.Div(
                            [
                                html.Div(
                                    [
                                        html.H5(
                                            "Portfolioverteilung nach Industrie", className="graph__title",
                                            style={'textAlign': 'center', 'backgroundColor': '#EFEFEF'}
                                        )
                                    ]
                                ),
                                dcc.Graph(
                                    id='industry',
                                    figure=fig_industry
                                ),
                            ],
                            className="graph__container second",
                        ),
                    ],
                    className="one-third column overview__direction",
                ),
            ],
            className="app__content",
        ),
    ],
    className="app__container", style={'backgroundColor': colors[3]},
)


# Installation einer interaktiven Bedienbarkeit der Applikation. In diesem Anwendungsbeispiel wird die
# Interaktion bei Selektion einzelner Zeilen der Portfoliouebersicht programmiert
@app.callback(
    Output('portfolio', 'figure'),
    [Input('datatable-row-ids', 'selected_rows')]
)
def update_graph(selected_rows):

    # Initialisierung der Variable 'selected_rows'. Diese beinhaltet die jeweils selektierten Zeilen
    # der Portfoliouebersicht
    if selected_rows is None:

        selected_rows = []

    securities = [df_table_pf.loc[i, 'security_id'] for i in selected_rows]

    # Fallunterscheidung nach Selektion einzelner Zeilen der Portfoliouebersicht. Fall 1: Keine Zeile ist ausgewaehlt.
    # In diesem Fall wird die Wertentwicklung des gesamten Portfolios seit Erstinvestition grafisch abgetragen
    if selected_rows == []:

        # Erstellung der Liniengrafik
        figure = {
            'data': [
                {'x': df_dash.index, 'y': (df_dash['portfolio_value'] / df_dash['initial_value'] - 1)*100,
                 'type': 'line', 'name': 'Portfolio'}
            ],
            'layout': {
                'title': 'Mein Portfolio',
                'xaxis': {'title': 'Jahr'},
                'yaxis': {'title': 'Wertentwicklung (in %)'},
                'plot_bgcolor': '#FFFFFF',
                'paper_bgcolor': '#FFFFFF',
            },
        }

    # Fall 2: Mindestens eine Zeile der Portfoliouebersicht ist ausgewaehlt
    else:

        # Bestimmung des letzten Erstinvestitionstages ueber alle ausgewaehlten security IDs hinweg. Erst ab
        # diesem Handelstag werden die Wertentwicklungen der unterschiedlichen security IDs gegeneinander verglichen.
        # Speicherung des Handelstags in der Variablen 'init'
        init = max([initial_date[i] for i in securities])

        # Speicherung des Handelstags im Format datetime zur Weiterverarbeitung
        init = datetime.strptime(init, '%Y-%m-%d').date()

        # Berechnung der Wertentwicklung des gesamten Portfolios seit dem Handelstag 'init'. Speicherung im
        # Listenelement 'data'
        data = [{'x': df_dash[df_dash.index >= init].index,
                 'y': ((df_dash.loc[df_dash.index >= init, 'portfolio_value'] /
                        df_dash.loc[df_dash.index >= init, 'initial_value']) - 1) * 100 -
                      (((df_dash.loc[df_dash.index == init, 'portfolio_value'] /
                         df_dash.loc[df_dash.index == init, 'initial_value']) - 1) * 100)[0],
                 'type': 'line', 'name': 'Portfolio'}]

        # Iteration nach selektierten security IDs
        for i in securities:

            # Speicherung des Tickers der jeweils zu iterierenden security ID in der Variable 'name'
            name = (str(df_portfolio.loc[df_portfolio['security_id'] == i, 'Ticker']).split(' ')[4]).split('\n')[0]

            # Ausgabe einer Listenlaenge in der Variablen 'count'. Diese ermoeglicht den Zugriff auf den Wert
            # der Wertentwicklung der zu iterierenden security ID
            count = len((str(((var[i].loc[var[i]['date'] == init, 'portfolio_value'] / var[i].loc[
                var[i]['date'] == init, 'initial_value']) - 1) * 100).split(' ')))

            # Berechnung der Wertentwicklung der zu iterierenden security ID seit dem Handelstag 'init'.
            # Speicherung in einem Listenelement, dass der Liste 'data' hinzugefuegt wird
            data = data + [{'x': var[i].loc[var[i]['date'] >= init, 'date'],
                            'y': (((var[i].loc[var[i]['date'] >= init, 'portfolio_value'] /
                                    var[i].loc[var[i]['date'] >= init, 'initial_value']) - 1) * 100)
                                 - pd.to_numeric(
                                (str(((var[i].loc[var[i]['date'] == init, 'portfolio_value'] /
                                       var[i].loc[var[i]['date'] == init, 'initial_value'])
                                      - 1) * 100).split(' ')[count-2]).split('\n')[0]),
                            'type': 'line', 'name': name}]

        # Erstellung der Liniengrafik
        figure = {
            'data': data,
            'layout': {
                'title': 'Mein Portfolio',
                'xaxis': {'title': 'Jahr'},
                'yaxis': {'title': 'Wertentwicklung (in %)'},
                'plot_bgcolor': '#FFFFFF',
                'paper_bgcolor': '#FFFFFF',
            },
        }

    # Ausgabe der erstellten Liniengrafik an die Appliaktion in Dash
    return figure


if __name__ == '__main__':
    app.run_server(debug=True)