# Code Portfolioanalyse
# @author: Marcel Zeuch
# @since: 2020-06-30
# @version: 1.0

# Importierung der benoetigten Bibliotheken
import mysql.connector
import os
import pandas as pd
import requests
from time import sleep

# Festsetzung der URL zur Anbindung an die API von Alpha Vantage
api_url = 'https://www.alphavantage.co/query'

# Initialisierung der Verbindung zur MySQL-Datenbank
connection = mysql.connector.connect(host=HOST,
                                     database='data_science',
                                     user=USERNAME,
                                     password=PASSWORT,
                                     allow_local_infile='True')

cursor = connection.cursor()


## ----- (1/3) Anfrage und Speicherung statischer Daten und der Marktdatenhistorie neuer Wertpapiere ----- ##

# Abfrage aller security IDs zu denen noch keine Statics angelegt worden
sql_select = "select id from statics where ticker is null"
cursor.execute(sql_select)
df_check = pd.DataFrame(cursor.fetchall())

# Anlegen von Statics, falls es security IDs gibt, zu denen noch keine Statics in der Datenbank gespeichert worden
if len(df_check) != 0:

    # Zusammenstellung aller ISINs der jeweiligen security IDs und Speicherung im DataFrame 'df_isin'
    sql_select = "select id, isin from statics where ticker is null"
    cursor.execute(sql_select)
    df_isin = pd.DataFrame(cursor.fetchall())

    # Anfrage des jeweiligen Ticker ueber die API
    for i in range(0, len(df_isin)):

        # Pausieren der Anfrage nach jeweils fuenf security IDs fuer 60 Sekunden
        if (i != 0) and (i % 5 == 0):
            sleep(60)

        # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
        inp = {"function": 'SYMBOL_SEARCH',
               "keywords": df_isin[1][i],
               "apikey": APIKEY}

        # Suchanfrage an die Schnittstelle und Datenspeicherung durch Update der Datenbank.
        # Fehlerausgabe im Fall nicht vorhandener Daten
        try:
            response = requests.get(api_url, inp)
            out = response.json()

            sql_update = "update statics set ticker = '" + \
                         (out['bestMatches'][0])['1. symbol'] + "', name = '" + \
                         (out['bestMatches'][0])['2. name'] + "', currency = '" + \
                         (out['bestMatches'][0])['8. currency'] + "' where id = " + str(df_isin[0][i])
            cursor.execute(sql_update)
            connection.commit()
        except:
            print("Fuer folgende ISIN wird kein Ticker gefunden: " + str(df_isin[1][i]))

    # Pausieren fuer 60 Sekunden
    sleep(60)

    # Zusammenstellung aller Ticker der jeweiligen security IDs und Speicherung im DataFrame 'df_ticker'
    sql_select = "select id, ticker from statics where ticker is not null"
    cursor.execute(sql_select)
    df_ticker = pd.DataFrame(cursor.fetchall())

    # Anfrage weiterer statischer Daten ueber die API
    for i in range(0, len(df_ticker)):

        # Pausieren der Anfrage nach jeweils fuenf security IDs fuer 60 Sekunden
        if (i != 0) and (i % 5 == 0):
            sleep(60)

        # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
        inp = {"function": 'OVERVIEW',
               "symbol": df_ticker[1][i],
               "apikey": APIKEY}

        # Suchanfrage an die Schnittstelle und Datenspeicherung durch Update der Datenbank.
        # Fehlerausgabe im Fall nicht vorhandener Daten
        try:
            response = requests.get(api_url, inp)
            out = response.json()

            sql_update = "update statics set country = '" + out['Country'] + "', industry = '" + \
                         out['Sector'] + "' where id = " + str(df_ticker[0][i])
            cursor.execute(sql_update)
            connection.commit()
        except:
            print("Fuer folgende security ID werden keine Statics gefunden: " + str(df_ticker[0][i]))

    # Pausieren fuer 60 Sekunden
    sleep(60)

    # Festsetzen eines Zaehlers
    count = 0

    # Anfrage der gesamten historischen Marktdaten ueber die API fuer die neu angelegten security IDs
    for i in range(0, len(df_ticker)):

        # Pausieren der Anfrage nach jeweils fuenf security IDs fuer 60 Sekunden
        if (i != 0) and (i % 5 == 0):
            sleep(60)

        # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
        inp = {"function": 'TIME_SERIES_DAILY',
               "symbol": df_ticker[1][i],
               "outputsize": 'full',
               "apikey": APIKEY}

        # Suchanfrage an die Schnittstelle und Datenspeicherung im DataFrame 'dff'.
        # Fehlerausgabe im Fall nicht vorhandener Daten
        try:
            response = requests.get(api_url, inp)
            out = response.json()

            marketdata = out['Time Series (Daily)']
            df = pd.DataFrame.from_dict(marketdata, orient="index")
            sec = (pd.Series([df_ticker[0][i]]*len(df), index=df.index)).rename('security_id')
            df = pd.concat([sec, df], axis=1)

            # Zusammenfuegen der verschiedenen Marktdaten in einen DataFrame
            if i == count:
                dff = df
            else:
                dff = pd.concat([dff, df])
        except:
            count = count + 1
            print("Fuer folgende security ID werden keine Marktdaten gefunden: " + str(df_ticker[0][i]))

    # Temporaere Speicherung der Marktdaten in einer .csv Datei und Upload in die Datenbank
    dff.to_csv('tempfile.csv')

    sql_load = """load data local infile 'tempfile.csv' 
               into table data_science.marketdata_daily 
               fields terminated by ',' 
               optionally enclosed by '"' 
               ignore 1 lines"""
    cursor.execute(sql_load)
    connection.commit()

    os.remove('tempfile.csv')

    # Pausieren fuer 60 Sekunden
    sleep(60)


## ----- (2/3) Anfrage, Speicherung und Aktualisierung von Marktdaten bereits vorhandener Wertpapiere ----- ##

# Abfrage an die Datenbank: Ausgabe aller Wertpapiere, fuer die keine aktuellen Marktdaten in der Datenbank
# vorhanden sind. Speicherung im DataFrame 'df_ticker'
sql_select = """select * from 
             (select m.security_id as 'security_id', s.ticker as 'ticker', max(m.date) as 'last_date' from statics s 
             join marketdata_daily m on m.security_id = s.id 
             where s.ticker is not null 
             group by m.security_id) a 
             where a.last_date != curdate()-1"""
cursor.execute(sql_select)
df_ticker = pd.DataFrame(cursor.fetchall())

# Anfrage der Marktdaten ueber die API
for i in range(0, len(df_ticker)):

    # Pausieren der Anfrage nach jeweils fuenf security IDs fuer 60 Sekunden
    if (i != 0) and (i % 5 == 0):
        sleep(60)

    # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
    inp = {"function": 'TIME_SERIES_DAILY',
           "symbol": df_ticker[1][i],
           "apikey": APIKEY}

    # Suchanfrage an die Schnittstelle und Datenspeicherung durch Einschreiben in die Datenbank.
    # Fehlerausgabe im Fall nicht vorhandener Daten
    try:
        response = requests.get(api_url, inp)
        out = response.json()

        marketdata = out['Time Series (Daily)']
        df = pd.DataFrame.from_dict(marketdata, orient="index")

        # Restriktion der Marktdaten auf Daten die zeitlich nach dem letzten in der Datenbank vorhandenen Datum liegen
        dff = df[df.index > str(df_ticker[2][i])]

        for j in range(0, len(dff)):

            sql_insert = "insert into marketdata_daily (security_id, date, open, high, low, close, volume) values" + \
                         "(" + str(df_ticker[0][i]) + ", '" + \
                         dff.index[j] + "', '" + \
                         dff['1. open'][j] + "', '" + \
                         dff['2. high'][j] + "', '" + \
                         dff['3. low'][j] + "', '" + \
                         dff['4. close'][j] + "', '" + \
                         dff['5. volume'][j] + "')"
            cursor.execute(sql_insert)
            connection.commit()
    except:
        print("Fuer folgende security ID werden keine Marktdaten gefunden: " + str(df_ticker[0][i]))

# Pausieren fuer 60 Sekunden, falls Marktdaten zuvor gezogen worden
if len(df_ticker) > 0:
    sleep(60)


## ----- (3/3) Anfrage, Speicherung und Aktualisierung von FX Marktdaten des Waehrungspaares EURUSD ----- ##

# Abfrage an die Datenbank: Ausgabe der ersten Zeile der Datenbanktabelle fuer FX Marktdaten.
# Speicherung im DataFrame 'df_check'
sql_select = "select * from marketdata_fx_daily limit 1"
cursor.execute(sql_select)
df_check = pd.DataFrame(cursor.fetchall())

# Anfrage der FX Marktdaten ueber die API. Fallunterscheidung, ob bereits FX Marktdaten in der
# Datenbank vorhanden sind oder nicht
if len(df_check) == 0:

    # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
    inp = {"function": 'FX_DAILY',
           "from_symbol": 'EUR',
           "to_symbol": 'USD',
           "outputsize": 'full',
           "apikey": APIKEY}

    # Suchanfrage an die Schnittstelle und Datenspeicherung im DataFrame 'df'
    response = requests.get(api_url, inp)
    out = response.json()

    marketdata_fx = out['Time Series FX (Daily)']
    df = pd.DataFrame.from_dict(marketdata_fx, orient="index")

    # Temporaere Speicherung der FX Marktdaten in einer .csv Datei und Upload in die Datenbank
    df.to_csv('tempfile.csv')

    sql_load = """load data local infile 'tempfile.csv' 
                   into table data_science.marketdata_fx_daily 
                   fields terminated by ',' 
                   optionally enclosed by '"' 
                   ignore 1 lines"""
    cursor.execute(sql_load)
    connection.commit()

    os.remove('tempfile.csv')

else:

    # Abfrage an die Datenbank: Ausgabe des letzten Datums. Speicherung in der Variable 'last_date'
    sql_select = "select max(date) from marketdata_fx_daily"
    cursor.execute(sql_select)
    last_date = cursor.fetchone()[0]

    # Bereitstellung der Eingabeparameter fuer die Anfrage an die API
    inp = {"function": 'FX_DAILY',
           "from_symbol": 'EUR',
           "to_symbol": 'USD',
           "apikey": APIKEY}

    # Suchanfrage an die Schnittstelle und Datenspeicherung durch Einschreiben in die Datenbank
    response = requests.get(api_url, inp)
    out = response.json()

    marketdata_fx = out['Time Series FX (Daily)']
    df = pd.DataFrame.from_dict(marketdata_fx, orient="index")

    # Restriktion der FX Marktdaten auf Daten die zeitlich nach dem letzten in der Datenbank vorhandenen Datum liegen
    dff = df[df.index > str(last_date)]

    for i in range(0, len(dff)):
        sql_insert = "insert into marketdata_fx_daily (date, open, high, low, close) values " + \
                     "('" + dff.index[i] + "', '" + \
                     dff['1. open'][i] + "', '" + \
                     dff['2. high'][i] + "', '" + \
                     dff['3. low'][i] + "', '" + \
                     dff['4. close'][i] + "')"
        cursor.execute(sql_insert)
        connection.commit()
