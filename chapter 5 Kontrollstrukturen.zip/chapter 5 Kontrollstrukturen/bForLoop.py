# Die For-Schleife in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-25
# @version: 2020-04-25 V1

for iIndex in range(0, 10):
    print('Position der Schleife', iIndex)

# Iterieren ueber Listen
LInteger = [1, 10, 100, 1000, 10000,
            100000, 1000000, 10000000]

for iIndex in range(0, len(LInteger)):
    print(LInteger[iIndex])
