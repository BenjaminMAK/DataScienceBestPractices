# Die While-Schleife in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-25
# @version: 2020-04-25 V1


iZahl = 1
while iZahl < 10:
  print('Aktueller Zahlenwert:', iZahl)
  iZahl += 1