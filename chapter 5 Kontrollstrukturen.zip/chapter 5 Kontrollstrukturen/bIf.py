# Die If-Else Bedingung in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-25
# @version: 2020-04-25 V1

iA = 500
iB = 100

if iA > iB:
    print('iA ist groesser als iB')
else:
    print('iA ist nicht grosser als iB')

# Kunjugtion von Bedingugen
if iA > 499 and iA < 999:
    print('iA liegt im Wertebereich zwischen 499 und 999')

if iA == 499 or iA >= 500:
    print('iA ist entweder 499 oder grosser bzw. gleich 500')