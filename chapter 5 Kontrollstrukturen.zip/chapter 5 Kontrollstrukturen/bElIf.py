# Die If-Else Bedingung in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-25
# @version: 2020-04-25 V1

iA = 500


if iA <= 100:
    print('iA ist kleiner gleich 100')

elif iA <= 200:
    print('iA ist kleiner gleich 200')

elif iA <= 300:
    print('iA ist kleiner gleich 300')

elif iA <= 400:
    print('iA ist kleiner gleich 400')

elif iA <= 500:
    print('iA ist kleiner gleich 500')

else:
    print('iA muss großer sein als 500')