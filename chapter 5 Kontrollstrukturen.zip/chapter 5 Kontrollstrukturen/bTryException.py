# Die Try-Exception in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-25
# @version: 2020-04-25 V1

LNames = ['Marlene', 'Mareike', 'Nadine']
# Versuch des Zugriffes auf LNames[4] 
try:
  LNames[4]
except:
  print('Die Liste hat kein Element an dem Index')

# Genauere Spezifikation
try:
  LNames[4]
except IndexError as error:
  print('Die Liste hat kein Element an dem Index')