import pandas as pd
import numpy as np



import matplotlib.pyplot as plt



import seaborn as sns



from sklearn.utils.random import sample_without_replacement
from sklearn.utils import resample
from sklearn import preprocessing
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, precision_score


import tensorflow as tf


# Einlesen des Datensatzes als DataFrame Objekt
data_hr = pd.read_csv('/Users/kev/Desktop/Data/hr_data.csv',      # Dateipfad
                      sep =',',                 # Trennzeichen dass in der Datei verwendet wird
                      header=0,                 # Angabe der ersten Zeile die eingelesen und Spaltennamen verwendet werden soll
                      encoding='utf8',          # zu verwendende Kodierung beim Lesen/Schreiben des DataFrames
                      na_values='n/a')          # Interpretation fehlender Werte als Datentyp NaN

# Auswahl der ersten 3 Eintraege (Spalten) im Datensatz
# Anstelle von n=3 kann jede andere beliebige ganze Zahl eingegeben werden
data_hr.head(n=3)

# Ausgabe der im Datensatz enthaltenen Variablen und des zugehoerigen Datentyps
data_hr.dtypes

# Erzeugen einer Liste, welche alle in dem DataFrame enthaltenen Variablennamen beinhaltet
list(data_hr.columns)

# Auswahl eines DataFrames der nur eine Spalte mit Variablennamen Attrition besitzt.
data_hr[['Attrition']]

# Auswahl eines DataFrames der zwei Spalten mit den Variablennamen Attrition und Education besitzt.
data_hr[['Age', 'Education']]

# Zuordnen des ausgewaehlten Teils des DataFrames zu einer expliziten Variable
# Operationen auf data_hr_slice wirken sich nicht auf die Werte in data_hr aus
data_hr_slice = data_hr[['Age', 'Education']]

# Auswahl einer Series/ eines Spaltenvektors
# Beachte: Kein DataFrame Objekt!
data_hr['Age']

# Auswahl der Zeile 0 des DataFrames
data_hr.iloc[0]

# Auswahl der Spalte 0 des DataFrames
# Beachte: Der angezeigte Bereich ein Series Objekt kein DataFrame
data_hr.iloc[:, 0]

# Auswahl der Zeilen 0, 3 und 7 des DataFrames
data_hr.iloc[[0,3,7]]

# Auswahl aller Zeilen von 0 bis 5 (=6-1) DataFrames
data_hr.iloc[0:6]

# Auswahl aller Zeilen und der einzelnen Spalten 1, 2 und 5
data_hr.iloc[:, [1,2,5]]

# Auswahl aller Zeilen von 0 bis 1 mit den Spalten 0 bis 40
# Beachte: Es existieren nur 35 Spalten. Dennoch wird kein IndexError ausgeloest, 
# sondern nur die maximal moegliche Anzhal angezeigt
data_hr.iloc[0:2, 0:40]

# Beispiel 1
# Auswahl aller Beobachtungen/ Zeilen fuer die der Wert der Spalte Alter
# groesser-gleich 40 ist
data_hr[
    (data_hr['Age'] >= 40) # Der Boolean-Vektor testet die Spalte Age und ordnet jeder Zeile den Wert True zu,
        ]                  # fuer welche die Bedinung in der entsprechenden Spalte erfuellt ist

# Beispiel 2
# Auswahl aller Beobachtungen/ Zeilen fuer die die Werte der Spalten Agw
# und DistanceFromHome resueektive groesser-gleich 40 und kleiner 7 sind.
# Dabei werden nur die Spalten Age, Attrition und Education ausgegeben.
data_hr[
    (data_hr['Age'] >= 40) &                    # Wir verbinden die konjunktiven Bedingungen ueber den & Operator
    (data_hr['DistanceFromHome'] < 7)           # Nur wenn beide Bedingungen GLEICHZEITIG erfuellt sind, 
        ][['Age', 'Attrition', 'Education']]    # wird der Wert True zugeordnet
                                                # Wir kombinieren den Boolean-Vektor den wir fuer die Auswahl 
                                                # der Zeilen verwenden, mit einer Liste zur Auswahl von
                                                # Spalten / Variablen

# Fuegt dem DataFrame neue Variable mit dem Namen 'new_variable' hinzu.
# In jeder Spalte nimmt diese Vairable den Wert 5 an.
data_hr['new_variable'] = 5 

# Fuegt dem DataFrame neue Variable mit dem Namen 
# 'new_variable' hinzu. Der Wert dieser Variable 
# in einer Spalte entspricht dem Produkt der
# Werte der Variablen Age und Education aus
# der entsprechenden Spalte.
data_hr['Age_Education'] = data_hr['Age']*data_hr['Education']   

# Fuegt dem DataFrame neue Variable mit dem Namen 'older_than_30' hinzu.
# Die Variable nimmt den Wert 1 an, wenn der Wert Age der Observation
# groesser als 30 ist, sonst 0. 
data_hr['older_than_30'] = np.where(data_hr['Age'] > 30,             # Bedingung die auf True / Falase getestet wird
                                 1,                                  # Zugeordneter Wert wenn die Bedingung True ist
                                 0)                                  # Zugeordneter Wert wenn die Bedingung False ist

# Fuegt dem DataFrame neue Variable mit dem Namen 'age_bins' hinzu.
# Der Variable Varaible nimmt den Wert 1 an, wenn Age groesser als 0 und kleiner-gleich als 10 ist;
# den Wert 2 wenn Age groesser als 10 und kleiner-gleich 20 ist, ...
data_hr['age_bins'] = pd.cut(data_hr['Age'], 
               bins=[0, 10, 20, 30, 40, np.inf],
               labels=[1, 2, 3, 4, 5])

# Loeschen von Variablen
# Wir koennen nicht relevante Variablen / Spalten ueber die df.drop Methode loeschen.
# Dazu muessen wir dem Befehl die entsprechenden Variable(n) uebergeben.
# Der der Variablen 'new_variable', 'Age_Education' und 'older_than_30'
data_hr.drop(                           
    ['new_variable', 'Age_Education', 'older_than_30'],  # uebergebene Variablen
    axis = 1,                           # Axis=1 definiert, dass wir Spalten loschen moechten. 
    inplace = True                      # inplace=True stellt sicher, dass die Aenderungen in dem eigentlichen DataFrame
    )                                   # Objekt uebernommen werden, da Pandas ansonsten eine temporaere Kopie anlegt
                                        # dessen Aenderungen sich nicht auf das Original auswirken.

# Testen auf fehlende Werte
data_hr.isnull()
data_hr.isna()

# Kuenstlicher Datensatz
# Titel beinhaltet NaN Werte
df_example = pd.DataFrame({"Name": ['Ironman', 'Strange', 'Hulk'],
                           "Title": [np.nan, 'Dr.', np.nan]})

# Identifikation fehlender Werte
df_example.isna()

# Option 1
df_example.dropna(axis = 0)

# Option 2
df_example.dropna(axis = 1)

# Option 3
df_example.fillna('No Information')


# Gibt die Durchschnittswerte aus
mean = data_hr.mean()

#Gibt die Standardabweichungen aus
std = data_hr.std()

# Gibt die Anzahl der Nicht-Null Observationen aus
n = data_hr.count()

# Gibt die Medianwerte aus
med_ = data_hr.median()

# Gibt die Minimalwerte aus
min_ = data_hr.min()

# Gibt die Maximalwerte aus
max_ = data_hr.max()

# Gibt verschiedene Statistiken zurueck
summary_stats = data_hr.describe()

# Umwandlung binaerer Kategorien
data_hr['Attrition_Yes'] = np.where(data_hr['Attrition']=='Yes',       # Bedingung die geprueft wird          
                        1,                         # Zugeordneter Wert wenn die Bedingung True ist
                        0)                         # Zugeordneter Wert wenn die Bedingung False ist

# Die methode gibt uns die verschiedenen Werte welche die Variable
# annimmt aus. Zusaetzlich erhalten wir Informationen zu der Anzahl
# der Observationen welche die Werte annehmen.
data_hr['BusinessTravel'].value_counts()

# Instanziierung der Klasse
one_hot_encoder = OneHotEncoder()

# Schritt 1: 
# Anwendung der fit_transform() Methode
# Es wird eine duennbesetzte Matrix erzeugt, die nur aus 0en und 1en besteht
temp_object = one_hot_encoder.fit_transform(data_hr[['BusinessTravel']])

# Gibt eine Liste mit den Werten der Variable aus, welche in Dummy-Variablen umgewandelt wurden
# Wie zuvor angesprochen, wurden die Werte zunaechst alphabetisch geordnet.
one_hot_encoder.categories_

# Erzeugung der Namen fuer die umgewandelten Variablen
new_names = 'BusinessTravel' + '_' + one_hot_encoder.categories_[0]
 
 
 


# Schritt 2: 
# Erzeugung eines DataFrame Objekts,
# dass die umgewandelten Variablen beinhaltet
temp_df = pd.DataFrame(temp_object.toarray(),         # Die Matrix wird umgewandelt und erzeugt ein DataFrame
                       columns = new_names            # Dem DataFrame werden die neuen Namen zugeordnet
                      )

# Ausgabe des neu erzeugten DataFrames       
temp_df           

# Schritt 3: 
# Konkatenation des DataFrame Objekts mit dem 
# urspruenglichen DataFrame ueber die DataFrame.merge() Methode
data_hr = data_hr.merge(temp_df,                    # Das anzufuegende DataFrame
                        left_index=True,            # Die beiden DataFrames sollen auf Basis ihrer Indizes  
                        right_index=True)           # konkateniert werden, damit die entsprechenden Observationen 
                                                    # zusammengefuegt werden. 
   
# Loeschen der nun umgewandelten und als Dummies eingefuegten Variable 
data_hr = data_hr.drop('BusinessTravel', axis = 1)    


# Alternativ koennen wir die DataFrames auch ueber die concat methode konkatenieren
data_hr = pd.concat([data_hr, temp_df], axis=1)

# Funktion zur automatisierten Erkennung und Umwandlung kategorischer Variablen
def cat_encoder(data):       
    '''A function to automatically transform categorical variables into one hot encoded variables
       
       Deletes non-varying variables.
       
    '''
    # Löschen konstanter Variablen
    initial = data.columns
    for var in initial:
        if (len(data[var].value_counts()) == 1):
            data = data.drop(var, axis = 1)
            
    vars_ = data.columns
    num_vars = data._get_numeric_data().columns
    non_num_vars = list(set(vars_) - set(num_vars))
        
    dfs = []
    
    for var in non_num:
        encoder = OneHotEncoder()
        temp_object = encoder.fit_transform(data[[var]])
        name = str(var) + '_' + encoder.categories_[0]
        temp_df = pd.DataFrame(temp_object.toarray(), columns = name)
        dfs.append(temp_df)
        data = data.drop(var, axis = 1)
    dfs.append(data)
    
    outcome = pd.concat(dfs, axis = 1)
    
    return outcome

# Anwendung der Funktion
data_hr_transformed = cat_encoder(data_hr)

# Instanziierung der Klasse zur Normalisierung
min_, max_ = 0,1
normal_scaler = preprocessing.MinMaxScaler(feature_range = (min_, max_))
# Normalisierung der numerischen Variable Age
data_hr_transformed[['Age']] = normal_scaler.fit_transform(data_hr_transformed[['Age']])

# Instanziierung der Klasse zur Standardisierung
standard_scaler = preprocessing.StandardScaler()
# Standardisierung der numerischen Variable Age
data_hr_transformed[['Age']] = standard_scaler.fit_transform(data_hr_transformed[['Age']])


# Funktion zur Reskalierung numerischer Variablen durch
# Normalisierung oder Standardisierung
def rescaling(data, normalization = True, min_ = 0, max_ = 1):
    '''A function to rescale numerical variables of a data set.
    
    The default is normalization in the interval 0 and 1.
    Change min_ and max_ to alter the interval.
    To switch to standardization, set normalization = False'''
    
    # Identifikation der numerischen Variablen
    num = []
    
    for var in data.columns:                              
        
        if (data.dtypes[var] == np.int64) | (data.dtypes[var] == np.float64):
            if (len(data[var].value_counts()) == 1):      
                data = data.drop(var, axis = 1)
            else:
                num.append(var)
    
    # Normalisierung (Default)
    if normalization == True:
        
        # Instanziierung der Klasse zur Normalisierung zwischen
        # den Werten min_ und max_ die der Funktion uebergeben werden

        normal_scaler = preprocessing.MinMaxScaler(feature_range = (min_, max_))
        
        # Normalisierung der numerischen Variablen
        data[num] = normal_scaler.fit_transform(data[num])
    
    else:
        
        # Instanziierung der Klasse zur Standardisierung
        
        standard_scaler = preprocessing.StandardScaler()
        
        # Standardisierung der numerischen Variablen
        data[num] = standard_scaler.fit_transform(data[num])
        
    
    return data

# Anwendung der Funktion mit Standard-Parametern
# Demnach normalisieren wir die Daten in den Bereich zwischen 0 und 1
data_hr_rescaled = rescaling(data_hr_transformed)
data_hr_rescaled

# Zufaellige Auswahl 500 unterschiedlicher Observationen
random_index = sample_without_replacement(n_population=len(data_hr),        # Obere Grenze der ausgewaehlten Werte
                                          n_samples=500,                    # Anzahl der ausgewaehlten Werte
                                          random_state=0)                   # Kontrolle fuer moegliche Replikation

# Nachdem wir den Index erzeugt haben waehlen wir die entsprechenden Observationen
# ueber die df.iloc Operation aus. 
random_sample = data_hr.iloc[data_hr_rescaled]


# Anzeige der Wertauspraegungen der Variable unseres Interesses
data_hr_rescaled['Attrition_Yes'].value_counts()

# Upsampling der Minderheitsklasse 
up_sampled = resample(data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 1],                     # Datensatz der resampled werden soll 
                        n_samples=len(data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 0]),    # Neue Anzahl der enthaltenen Datenpunkte
                        replace=True)                                                               # Neue Datenpunkte können mehrfach gezogen werden
# Konkatenation der beiden Klassen
balanced_upsample = pd.concat([data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 0], up_sampled])

# Downsampling der Mehrheitsklasse
down_sampled = resample(data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 0],                    # Datensatz der resampled werden soll
                        n_samples=len(data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 1]),     # Neue Anzahl der enthaltenen Datenpunkte
                        replace=False)                                                               # Neue Datenpunkte können NICHT mehrfach gezogen werden
# Konkatenation der beiden Klassen
balanced_downsample = pd.concat([data_hr_rescaled[data_hr_rescaled['Attrition_Yes'] == 1], down_sampled])

# Definition einer Funktion die es erlaubt einen uebergebenen Datensatz
# durch Over- oder Undersampling zu Balancieren.
def balancing(target, df):
    ''' A simple function to balance a data set according to target input'''
    
    if df[target].value_counts()[0] == df[target].value_counts()[1]:
        print('Die Klassen sind ausbalanciert: ', '\n', df[target].value_counts())
        
        return df
       
    elif df[target].value_counts()[0] > df[target].value_counts()[1]:
        maj_class = df[target].value_counts().keys()[0]
        maj = df[target].value_counts()[0]
        majority = df[df[target] == df[target].value_counts().keys()[0]]
        
        min_class = df[target].value_counts().keys()[1]
        min_ = df[target].value_counts()[1]
        minority = df[df[target] == df[target].value_counts().keys()[1]]
    
    elif df[target].value_counts()[0] < df[target].value_counts()[1]:
        maj_class = df[target].value_counts().keys()[1]
        maj = df[target].value_counts()[1]
        majority = df[df[target] == df[target].value_counts().keys()[1]]
        
        min_class = df[target].value_counts().keys()[0]
        min_ = df[target].value_counts()[0]
        minority = df[df[target] == df[target].value_counts().keys()[0]]
        
    print('Die Klassen sind nicht ausbalanciert: \n'
         '\nDie Mehrheitsklasse ist ', target, '=', maj_class, ' mit ', maj, ' Observationen.'
         '\nDie Minderheitsklasse ist ', target, '=', min_class, ' mit ', min_, ' Observationen.')
    
    sampling = input('\nSoll Undersampling (u) oder Oversampling (o) betrieben werden? ')
    while sampling not in ['u', 'U', 'o', 'O']:
        sampling = input('Ungueltige Eingabe.' '\nSoll Undersampling (u) oder Oversampling (o) betrieben werden? ')
    
    
    if sampling in ['U', 'u']:
        
        down_sampled = resample(majority,
                                n_samples=min_,
                                replace=False)
        
        output = pd.concat([minority, down_sampled]).sample(frac=1)
        
        print('\nDer Datensatz wurde durch Undersampling ausbalanciert.')
    
    elif sampling in ['O', 'o']:
        
        up_sampled = resample(minority,
                             n_samples=maj,
                             replace=True)
        
        output = pd.concat([majority, up_sampled]).sample(frac=1)
        
        print('\nDer Datensatz wurde durch Oversampling ausbalanciert.')
    
    return output

# Anwendung der definierten Funktion
temporary = balancing('Attrition_Yes', data_hr_rescaled)

# Zufaellige Aufteilung des Datensatzes in Trainings- und Testdatensatz
X_train, X_test, Y_train, Y_test = train_test_split(
    data_hr_rescaled.drop(['Attrition_Yes', 'Attrition_No'], axis=1), # Trainingsdaten ausser binaere Labels
    data_hr_rescaled['Attrition_Yes'],                                # Binaeres Label unseres Interesses
    test_size=0.2,                                                    # Groesse des Testdatensatzes
    random_state=0)

# Oversampling
balanced = balancing('Attrition_Yes', 
                        pd.concat([X_train, Y_train], axis = 1)   # Wir konkatenieren die Features und Labels, um
                       )                                          # die Funktion anwenden zu koennen.

# Separierung von Labels und Features
X_train = balanced.drop(['Attrition_Yes'], axis=1)
Y_train = balanced['Attrition_Yes']

# Konkatenieren der Features und Labels des Trainingsdatensatzes
train_set_w_labels = pd.concat([X_train, Y_train], axis=1)

# Erzeugung einer Korrelationsmatrix
pearson_matrix = train_set_w_labels.corr(method = 'spearman')

# Korrelationen zwischen der abhaengigen und den unabhaengigen Variablen
pearson_matrix['Attrition_Yes'].sort_values(ascending=False)

# uebersicht zu Verteilungen und Moeglichen Zusammenhaengen durch einen Pairplot
sns.pairplot(train_set_w_labels[['Attrition_Yes',
                                 'MonthlyIncome',
                                 'JobLevel',
                                 'YearsAtCompany',
                                 'JobSatisfaction',
                                 'DistanceFromHome',
                                 'JobInvolvement',
                                 'WorkLifeBalance',
                                 'DailyRate']], 
             hue = 'Attrition_Yes',                            # 3. Dimension des Grafik
             markers=['D', 'o'],                               # Unterschiedliche symbolische
             kind='reg')                                       # Anzeigen linearer Zusammenhaenge

# Beziehungen zwischen Mittelwerten
sns.relplot(x='DistanceFromHome',
            y='MonthlyIncome', 
            hue='Attrition_Yes', style='Attrition_Yes',markers=True,
            kind='line',
            height=5, aspect=1.7,
            data=train_set_w_labels)

# Scatterplot, Verteilungen und lineare Zusammenhaenge
sns.jointplot('DistanceFromHome', 
              'MonthlyIncome',
              data=train_set_w_labels[train_set_w_labels['Attrition_Yes']==0],
              kind='reg')

sns.jointplot('DistanceFromHome', 
              'MonthlyIncome',
              data=train_set_w_labels[train_set_w_labels['Attrition_Yes']==1],
              kind='reg')

# Illustrationen fuer kategorische Variablen durch Verteilungen
sns.catplot(x='JobSatisfaction', 
            y='MonthlyIncome', 
            hue='Attrition_Yes', 
            data=train_set_w_labels,
            kind='bar')

sns.catplot(x='JobSatisfaction', 
            y='MonthlyIncome', 
            hue='Attrition_Yes', 
            data=train_set_w_labels,
            kind='violin')

sns.catplot(x='JobSatisfaction', 
            y='MonthlyIncome', 
            hue='Attrition_Yes', 
            data=train_set_w_labels,
            kind='box')

# Importieren der Algorithmus Klasse und der Methoden zu Berechnung von Performance-Kennzahlen
from sklearn.neighbors import KNeighborsClassifier

# Aufteilen der Daten in Trainings- und Testdaten
X_train, X_test, Y_train, Y_test = train_test_split(
    data_hr_rescaled.drop(['Attrition_Yes', 'Attrition_No'], axis=1), # Features
    data_hr_rescaled['Attrition_Yes'],                                # Binaeres Label unseres Interesses
    test_size=0.25,                                            # Groesse des Testdatensatzes
    random_state=0)

# Undersampling der Trainingsdaten
balanced = balancing('Attrition_Yes', pd.concat([X_train, Y_train], axis=1))

# Separierung von Labels und Features
X_train = balanced.drop(['Attrition_Yes'], axis=1)
Y_train = balanced['Attrition_Yes']

# Instanziierung und Training des Algorithmus
# Wir beginnen mit dem zufaellig ausgewaehlten Wert k=10. 
knnmodel = KNeighborsClassifier(n_neighbors=10).fit(X_train, Y_train)

# Definition einer Funktion die uns die Performance eines Modells ausgibt
def performance_tester(model, features, real_labels):
    '''A function to compute performance measures of a model on a test set'''
    

    
    # Benoetigte Libraries
    from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, precision_score
    
    # Predictions
    pred_labels = model.predict(features)
    
    # Metriken: Confusion Matrix, Accuracy, Precision, Recall
    cm = confusion_matrix(real_labels, pred_labels)
    acc = accuracy_score(real_labels, pred_labels)
    prec = precision_score(real_labels, pred_labels)
    rec = recall_score(real_labels, pred_labels)
    
    
    # Erzeugen eines DataFrames zur Visualisierung der Confusion Matrix
    df_cm = pd.DataFrame(cm, range(2), range(2))
    # Visualisierung CM
    fig = sns.heatmap(df_cm,
                      fmt='d',
                      annot=True, 
                      cmap="YlGnBu") 

    sns.set(font_scale=1.4) 
    plt.title('Confusion matrix', fontsize = 17)    # Titel + Schriftgroesse
    plt.xlabel('Predicted', fontsize = 15)                          # X-Achse + Schriftgroesse
    plt.ylabel('True', fontsize = 15)                               # Y-Achse + Schriftgroesse
    fig_size = plt.rcParams['figure.figsize']
    fig_size[0] = 5
    fig_size[1] = 5
    plt.rcParams["figure.figsize"] = fig_size
    plt.show()
    
    # Ausgabe von Accuracy, Precision, Recall
    print('Model performance:',
          '\nAccuracy: ', round(acc,3), '\n' + 'Precision: ', round(prec,3), '\n' + 'Recall: ', round(rec,3))

# Testen der Performance 
print('Training data performance:\n')
performance_tester(knnmodel, X_train, Y_train)
print(2*'\n', '\nTest data performance:\n')
performance_tester(knnmodel, X_test, Y_test)

# Hyperparameter Optimierung

# Liste zur Speicherung der Performance Metriken fuer bestimmte k Werte
accuracies = []
precisions = []
recalls = []

# aeussere Schleife fuer das Testen der Hyperparameter
# Wir testen: k = 1, ..., 15
for k in range(1,16):
    
    # Liste fuer die einzelnen Metriken der Cross-Validierung
    temp_accs = []
    temp_precs = []
    temp_recs = []
    
    # Cross-Validierung
    for val in range(0,15):
        # Zufaellige Aufteilung der Trainingsdaten
        X_train_, X_val, Y_train_, Y_val = train_test_split(
            X_train, 
            Y_train, 
            test_size=0.1,    # 20 % werden als Validierungsdatensatz verwendet 
            random_state=val) # Zufallszahl zur Replikation
        
        # Modell schaetzen
        knnmodel = KNeighborsClassifier(n_neighbors=k).fit(X_train_, Y_train_)
        
        # Vorhersagen
        Y_val_pred = knnmodel.predict(X_val)
        
        # Abhaengig vom Problem koennen unterschiedliche Metriken besser sein
        acc = accuracy_score(Y_val, Y_val_pred)
        prec = precision_score(Y_val, Y_val_pred)
        rec = recall_score(Y_val, Y_val_pred)
        
        # Performance Metrik fuer die einzelnen Runde der Validierung
        temp_accs.append(acc)
        temp_precs.append(prec)
        temp_recs.append(rec)

      
    # Berechnung der durchschnittlichen Performance fuer einen bestimmten k Wert
    # Durchschnitt wird der initialen Liste hinzugefuegt
    accuracies.append(np.mean(temp_accs))
    precisions.append(np.mean(temp_precs))
    recalls.append(np.mean(temp_recs))

# Performance-Metriken verschiedener k Werte
plt.plot(range(1, 16), accuracies)
plt.plot(range(1, 16), precisions)
plt.plot(range(1, 16), recalls)
plt.xlim(1,15)
plt.xticks(range(1, 16))

# Grafik Spezifikationen
plt.xlabel('Number of Neighbors k')
plt.ylabel('Performance')
plt.legend(['Accuracy', 'Precision', 'Recall'])
plt.title('Comparison of performance measures')
plt.tick_params(direction='out', length=6, width=3, colors='b',
               grid_color='b', grid_alpha=0.5)
fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 12
fig_size[1] = 5
plt.rcParams["figure.figsize"] = fig_size

plt.show()

# Ausgabe der optimalen k-Werte bezogen auf unterschiedliche Performance Kennzahlen
opt_k_acc = np.argmax(accuracies) + 1
opt_k_prec = np.argmax(precisions) + 1
opt_k_rec = np.argmax(recalls) + 1
print('Optimales k Accuracy =', opt_k_acc, 
      '\nOptimales k Precision =', opt_k_prec,
      '\nOptimales k Recall =', opt_k_rec)

# Instanziierung und Training des Algorithmus mit Accuracy optimalem k-Wert
knnmodel = KNeighborsClassifier(n_neighbors=opt_k_acc).fit(X_train, Y_train)

# Testen der Performance 
print('Training data performance:\n')
performance_tester(knnmodel, X_train, Y_train)
print(2*'\n', '\nTest data performance:\n')
performance_tester(knnmodel, X_test, Y_test)

# Abspeichern des trainierten Modells
from joblib import dump, load
dump(knnmodel, 'PATH/knn.joblib') 

# Laden des trainierten Modells
clf = load('PATH/knn.joblib') 

# Import des RandomForest Classifiers von Scikit-Learn
from sklearn.ensemble import RandomForestClassifier

# Aufteilung der Daten in Trainings- und Testdaten
X_train, X_test, Y_train, Y_test = train_test_split(
    data_hr_rescaled.drop(['Attrition_Yes', 'Attrition_No'], axis=1), # Trainingsdaten ausser binaere Labels
    data_hr_rescaled['Attrition_Yes'],                                # Binaeres Label unseres Interesses
    test_size=0.25,                                                    # Groesse des Testdatensatzes
    random_state=0)

# Undersampling
balanced = balancing('Attrition_Yes', pd.concat([X_train, Y_train], axis=1))

# Separierung von Labels und Features
X_train = balanced.drop(['Attrition_Yes'], axis=1)
Y_train = balanced['Attrition_Yes']

# Training eines Modells mit zufaelligen Hyperparametern
random_forest_model = RandomForestClassifier(
    max_depth=3,                                 # Maximale Tiefe einzelner Baeume
    n_estimators=10,                             # Anzahl einzelner Klassifikationsbaeume                        
).fit(X_train, Y_train)

# Testen der Performance 
print('Training data performance:\n')
performance_tester(random_forest_model, X_train, Y_train)
print(2*'\n', '\nTest data performance:\n')
performance_tester(random_forest_model, X_test, Y_test)
   
# Hyperparameter Optimierung
# Variation der maximal moeglichen Tiefe der einzelnen Baeume
# Array von 3 Zahlen die im gleichen Abstand zwischen 2 und 7 liegen:
# 2,3,4,5,6,7
max_depth = np.linspace(2, 7, 6)

# Anzahl der Baeume im Wald
# Array von 0 bis N-1, jeweils um 1 erhoeht und mit 10 multipliziert:
# 10,20,30,40,50,60,70, 90, 100
n_trees = (np.arange(10)+1)*10

# Accuracies bestimmter Kombinationen
accuracies = []
precisions = []
recalls = []

# Schleife ueber die Tiefe der Baeume
for d in max_depth:
    # Schleife ueber die Anzahl der Baeume
    for n in n_trees:
        
        # Accuracies einzelner Validierungen
        temp_accs = []
        temp_precs = []
        temp_recs = []
        
        for val in range(15):
            
            # Zufaellige Aufteilung der Trainingsdaten
            X_train_, X_val, Y_train_, Y_val = train_test_split(
                X_train, 
                Y_train, 
                test_size=0.2,    # 20 % werden als Validierungsdatensatz verwendet 
                random_state=val) # Zufallszahl zur Replikation

            # Modell schaetzen
            random_forest_model = RandomForestClassifier(
                max_depth=d,
                n_estimators=n).fit(X_train_, Y_train_)

            # Vorhersagen
            Y_val_pred = random_forest_model.predict(X_val)

            # Performance Metrik, hier: Accuracy
            # Abhaengig vom Problem koennen unterschiedliche Metriken besser sein
            acc = accuracy_score(Y_val, Y_val_pred)
            prec = precision_score(Y_val, Y_val_pred)
            rec = recall_score(Y_val, Y_val_pred)

            # Performance Metrik fuer die einzelnen Runde der Validierung
            temp_accs.append(acc)
            temp_precs.append(prec)
            temp_recs.append(rec)
            
        # Zufuegen des Durchschnittswertes und der n,d Kombination zu der Liste
        accuracies.append([np.mean(temp_accs), d, n])
        precisions.append([np.mean(temp_precs), d, n])
        recalls.append([np.mean(temp_recs), d, n])

# Identifikation der optimalen Werte
temp_acc = []
temp_rec = []
temp_prec = []

for i in range(len(accuracies)):
    temp_acc.append(accuracies[i][0])
    temp_rec.append(recalls[i][0])
    temp_prec.append(precisions[i][0])
opt_acc = np.argmax(temp_acc)
opt_rec = np.argmax(temp_rec)
opt_prec = np.argmax(temp_prec)

d_opt_acc = accuracies[opt_acc][1]
n_opt_acc = accuracies[opt_acc][2]

d_opt_rec = accuracies[opt_rec][1]
n_opt_rec = accuracies[opt_rec][2]

d_opt_prec = accuracies[opt_prec][1]
n_opt_prec = accuracies[opt_prec][2]

print('\nAccuracy:', '\nOptimal depth of trees: ', d_opt_acc, '\nOptimal number of trees: ', n_opt_acc)
print('\nRecall:', '\nOptimal depth of trees: ', d_opt_rec, '\nOptimal number of trees: ', n_opt_rec)
print('\nPrecision:', '\nOptimal depth of trees: ', d_opt_prec, '\nOptimal number of trees: ', n_opt_prec)

# Training mit optimierten Hyperparametern
random_forest_model = RandomForestClassifier(
    max_depth=d_opt_rec,                                 
    n_estimators=n_opt_rec,                               
).fit(X_train, Y_train)

# Testen der Performance 
print('Training data performance:\n')
performance_tester(random_forest_model, X_train, Y_train)
print(2*'\n', '\nTest data performance:\n')
performance_tester(random_forest_model, X_test, Y_test)

# Zuweisung der Importance-Werte als Spaltenvektor
feature_importances = pd.Series(random_forest_model.feature_importances_, index = X_train.columns)
# Grafische Illustration der 10 einflussreichsten Merkmale
feature_importances.nlargest(10).plot(kind='barh')
plt.show()
