# Anwendungsbeispiel Videospiele
# @author: Benjamin M. Abdel-Karim
# @since: 2020-05-01
# @version: 2020-05-201 - V1
# Imports
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import statsmodels.formula.api as smf
import numpy as np
# -------------------------------
# Import und Pre-Processing
# -------------------------------
# Import der .CSV Datei als DataFrame.
df = pd.read_csv('dataset_GoT.csv',  sep=',')

# Eininge Statisitken ueber die Daten.
# Anzahl der Spalten und Informationen ueber die
# Spaltenbezeichung
# Infos zu den dtypes, Nicht-Null-Werte und Speicherverbrauch.
print('Anzahl der Spalten:' + ' ', len(df.columns))
print('Variablen:' + ' ', df.columns.to_list())
print(df.info())

# Summe der Not-a-Number Werte im Datensatz.
print('Anzahl NaN:' + ' ', df.isnull().sum())


# -------------------------------
# Explore the data
# -------------------------------
# Erste uebersicht der Daten.
print(df.describe())

# Erstellen eines Graphen mit Hilfe des Networks Moduls
# aus einem DataFrame Objekt.
Graph = nx.Graph()
Graph = nx.from_pandas_edgelist(df, source='source', target='target', edge_attr='contact', create_using=Graph)

# Funktion fuer die Erstellung einer Abbildung
# @param: Graph Objekt, Labels, Bezeichung, Format
# @return: none, speichert die Abbildung im gewuensten Format.
def fGeneratePlot(Graph, bLabes, sFigureName, sFormat):
    LNodeDegree = []
    LNodeSize = []
    LNames = []

    # Liste fuer die Berechnung des Grades.
    for node in Graph:
        LNames.append(node)
        dDegree = Graph.degree(node)
        LNodeDegree.append(float(dDegree))

        # Potenzierung des Gerades fuer eine bessere Knoten groesse.
        LNodeSize.append(dDegree ** 2)

    # Positionierung der Knoten
    DicPos = nx.kamada_kawai_layout(Graph)

    # Abbildung erstellen
    plt.figure(figsize=(12, 8))
    nx.draw_networkx_edges(Graph, DicPos, alpha=0.1, edge_size=1, edge_color='grey')
    nx.draw_networkx_nodes(Graph, DicPos, node_size=LNodeSize, cmap=plt.cm.binary_r,
                           node_color=LNodeDegree, alpha=0.7)

    if bLabes == True:
        nx.draw_networkx_labels(Graph, pos=DicPos, font_size=5, alpha=0.5)
    plt.axis('off')

    sFigureNameAsFormat = sFigureName + sFormat
    plt.savefig(sFigureNameAsFormat, bbox_inches='tight')
    plt.show()

# Verwendung der Funktion
# fGeneratePlot(Graph, False, 'GameOfThrones', '.pdf')


# -------- SNA Metriken ---------
# Erstelle DataFrame zum Speichern der Informationen
df_Nodes = pd.DataFrame(columns=['node', 'degree', 'betweenness', 'centrality'])

DicBetweenness = nx.betweenness_centrality(Graph)
DicDegreeCentrality = nx.degree_centrality(Graph)

for node in Graph:
        # Zugriff auf die Werte
        dDegree = Graph.degree(node)
        dBetweenness = DicBetweenness.get(node)
        dCentrality = DicDegreeCentrality.get(node)

        df_Nodes = df_Nodes.append({'node': node,
                                    'degree': float(dDegree),
                                    'betweenness': dBetweenness,
                                    'centrality': dCentrality
                                    }, ignore_index=True)

df_Nodes = df_Nodes.sort_values(by='degree', ascending=False)

df_NodesTopTen = df_Nodes[0:10]
df_NodesTopTen.to_latex('tab-df_NodesTopTen.tex', float_format="%.2f", index=False, index_names=False)


# -------- Degree Verteilung ---------
# Berechne den Anteil jedes Degree auf Basis der Gesamtverteilung.
# Lege hierzu eine neue Spalte im DataFrame an um den Anteil entsprechend
# zu speichern. Ueber Uniquze werden alle moeglichen Degrees erfasst.
# Der relativer Anteil wird durch die Division bestimmt.
# Anschliessend werden die Datenpunkte fuer die Darstellung sortiert.
df_Nodes['perc'] = df_Nodes['degree']/len(df_Nodes['degree'])
LDegreePerc = sorted(df_Nodes['perc'], reverse=True)

# Darstellung erstellen
fig, ax = plt.subplots()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.loglog(LDegreePerc, "ko")
ax.set_xlabel(xlabel='Degree')
ax.set_ylabel(ylabel='Probability')
plt.savefig('LogLogDegree.pdf', bbox_inches='tight')
plt.show()


# -------------------------------
# Model the data
# -------------------------------
df_Nodes.loc[df_Nodes['node'].str.contains('Stark'), 'good'] = 1
df_Nodes.loc[df_Nodes['good'] != 1, 'good'] = 0

# Erstellung des Modell
sFormula = 'good ~ degree + betweenness + centrality'
LogitModel = smf.logit(formula=sFormula, data=df_Nodes).fit()
LogitModel.summary()
print(LogitModel.summary())

df_model_odds = pd.DataFrame(np.exp(LogitModel.params), columns= ['Odds-Ratio'])
df_model_odds['z-value'] = LogitModel.pvalues
print(df_model_odds)
