# -*- coding: utf-8 -*-
"""
Created on Mon Oct 26 15:41:31 2020

@author: Katharina
"""

#%%
# Die Libraries pandas und numpy importieren, die fuer die Auswertung benoetigt werden
import pandas as pd
import numpy as np


#%%
# Einlesen der Daten aus einer Excel-Datei mit zwei Tabellenblaettern

# Einlesen des Tabellenblattes 1 (Auswahlentscheidungen)
df_choices = pd.read_excel("Datensatz_Electric Vehicles_simuliert.xlsx", sheet_name="Choices")
# Anzeigen der ersten 5 Zeilen des ersten Tabellenblattes (Auswahlentscheidungen)
print(df_choices.head())

# Einlesen des Tabellenblattes 2 (Studiendesign)
df_study_design = pd.read_excel("Datensatz_Electric Vehicles_simuliert.xlsx", sheet_name="Studiendesign Choice Sets")
# Anzeigen der ersten 5 Zeilen des zweiten Tabellenblattes (Studiendesign)
print(df_study_design.head())

#%%
# Zusammenfuehrung der Daten zu einem Datensatz 

# Erstellen einer Liste mit 42 Zeilen, wobei jeweils 3 Zeilen als Choice Set zusammengehoeren
iX_ChoiceSet = range(1, 15)
iN_ChoiceSet = 3
new_ChoiceSet = [item for item in iX_ChoiceSet for i in range(iN_ChoiceSet)]
print(new_ChoiceSet)

# Hinzufuegen der Liste als neue Spalte in study_design
df_study_design.insert(0, "ChoiceSet", new_ChoiceSet)

# Kopieren der Tabelle, um 250 Teilnehmer abzubilden
df_dataset = df_study_design.append([df_study_design] * 249)

# Einfuegen einer ID Spalte 
x_ID = range(1,251)
n_ID = 42
new_ID = [item for item in x_ID for i in range(n_ID)]
df_dataset.insert(0, "ID", new_ID)

#%%

# Entfernen der Spalte UserID
df_choices_new = df_choices.drop(columns=['UserID'])
df_choices_new.head()

# Erstellen einer Liste aus dem Datensatz 'choices'
LdfRows = df_choices_new.to_numpy().tolist()

# Erstellen einer flachen Liste aus der Liste der Listen
import operator
from functools import reduce
LRows2 = reduce(operator.concat, LdfRows)

# Liste jeweils 3mal wiederholen
S_repeated = pd.Series(LRows2)
S_repeated = S_repeated.repeat(3)

# Serie in Liste konvertieren
LRepeatedList = S_repeated.to_numpy().tolist()
df_dataset.insert(0, "Choice", LRepeatedList)

# Liste mit drei Optionen (pro Choice Set) und 3500 mal wieder holen (3*3500 =10500)
def duplicate(testList, n):
    return testList*n
LChoiceOptions = [1, 2, 3]
LChoice_Option = duplicate(LChoiceOptions, 3500)

# Neue Spalte im Datensatz fuer ChoiceOption
df_dataset.insert(0, "ChoiceOption", LChoice_Option)
 
# Neue Spalte fuer: Auswahl (selected=1), die anderen beiden Optionen wurden nicht ausgewaehlt (selected=0)
df_dataset['selected'] = np.where((df_dataset['ChoiceOption'] 
                            == df_dataset['Choice']), 1, 0)

# Uebersicht Datensatz mit gewaehlter Anordnung der Spalten
df_dataset = df_dataset[["ID", "ChoiceSet", "ChoiceOption", "Choice", "selected", "Reichweite", "Kaufpreis", "Ladedauer", "Stromkosten","Motorleistung"]]
# Ausgabe Datensatz
print(df_dataset)

#%%
# Spalte 'selected' in 'endog' Dataset abspeichern
S_endog = df_dataset[["selected"]]

# Die Spalten der Attribute in neuem Datensatz abspeichern
df_x = df_dataset[["Reichweite", "Kaufpreis", "Ladedauer", "Stromkosten", "Motorleistung"]]
#%%

# Dummy-Codierung
df_xdum = pd.get_dummies(df_x, columns=[c for c in df_x.columns])

# Anzeigen der ersten 5 Zeilen von xdum
print(df_xdum.head())

#%%

# Effektkodierung
df_effect_dum = pd.DataFrame()
for row in df_xdum.to_dict(orient="records"):
    if row["Reichweite_4"] == 1:
        row["Reichweite_1"] = -1
        row["Reichweite_2"] = -1
        row["Reichweite_3"] = -1
    row.pop("Reichweite_4", None)
    if row["Kaufpreis_4"] == 1:
        row["Kaufpreis_1"] = -1
        row["Kaufpreis_2"] = -1
        row["Kaufpreis_3"] = -1
    row.pop("Kaufpreis_4", None)
    if row["Ladedauer_2"] == 1:
        row["Ladedauer_1"] = -1
    row.pop("Ladedauer_2", None)
    if row["Stromkosten_4"] == 1:
        row["Stromkosten_1"] = -1
        row["Stromkosten_2"] = -1
        row["Stromkosten_3"] = -1
    row.pop("Stromkosten_4", None)
    if row["Motorleistung_2"] == 1:
        row["Motorleistung_1"] = -1
    row.pop("Motorleistung_2", None)
    df_effect_dum = df_effect_dum.append(row, ignore_index=True)

# Umbenennung aus Ausgabe der exogenen Variablen
exog = df_effect_dum
print(exog)

#%%

# Schaetzung der Parameterwerte
import statsmodels.discrete.discrete_model
S_endog = S_endog.reset_index(drop=True)
res = statsmodels.discrete.discrete_model.MNLogit(S_endog, exog).fit(maxiter=10000)
print(res.summary())


#%%
# Speichern der Parameternamen und -werte in einem Datensatz
df_modelValues = pd.DataFrame(columns=['param_name', 'param_w'])

# Speichern der Parameter in ndarrays
LVariables = res.params.index.values
LParamValues = res.params.values

# ndarrays in Listen konvertieren
# Mit .flatten () wird die Dimension von 2D auf 1D reduziert
LVariables = LVariables.tolist()
LParamValues = LParamValues.flatten()

dValue = LParamValues[0]

#%%

# Iteration ueber die Modelldaten
for iIndex in range(len(LVariables)):
    sVariable = LVariables[iIndex]
    dValue = LParamValues[iIndex]
    print(sVariable, str(dValue))

    # Hinzufuegen der Werte im Datensatz
    df_modelValues = df_modelValues.append({
        'param_name': sVariable,
        'param_w': dValue}, ignore_index=True)

df_res = df_modelValues


#%%
# Berechnung der fehlenden Werte (Referenzlevel)
df_ommitted_params = pd.DataFrame({'param_name': 
            ['Kaufpreis_4','Ladedauer_2','Motorleistung_2',
            'Reichweite_4', 'Stromkosten_4'],
            'param_w':
            [-(df_res.param_w[0] + df_res.param_w[1] + df_res.param_w[2]), 
            -(df_res.param_w[3]), 
            -(df_res.param_w[4]),
            -(df_res.param_w[5] + df_res.param_w[6] + df_res.param_w[7]),
            -(df_res.param_w[8] + df_res.param_w[9] + df_res.param_w[10])]
            }, 
            columns=['param_name', 'param_w'])
    
# Erstellen eines gemeinsamen Dataframes fuer alle Parameterwerte
df_all = pd.concat([df_res,df_ommitted_params], ignore_index=True)

# Sortierung des Dataframes entsprechend der Parameternamen
df_all = df_all.sort_values(by='param_name', ascending=True)

print(df_all)

#%%
# Spalte Param_name als Index setzen
df_all.index = df_all['param_name']

# Die Parameterwerte der Attribute werden gruppenweise in einem Array gespeichert
ndarray_A = np.array([[df_all["param_w"]["Kaufpreis_1"],
                       df_all["param_w"]["Kaufpreis_2"] ,
                       df_all["param_w"]["Kaufpreis_3"],
                       df_all["param_w"]["Kaufpreis_4"]],
                      [df_all["param_w"]["Ladedauer_1"],
                       df_all["param_w"]["Ladedauer_2"]],
                      [df_all["param_w"]["Motorleistung_1"],
                       df_all["param_w"]["Motorleistung_2"]],
                      [df_all["param_w"]["Reichweite_1"],
                       df_all["param_w"]["Reichweite_2"],
                       df_all["param_w"]["Reichweite_3"] ,
                       df_all["param_w"]["Reichweite_4"]],
                      [df_all["param_w"]["Stromkosten_1"],
                       df_all["param_w"]["Stromkosten_2"],
                       df_all["param_w"]["Stromkosten_3"] ,
                       df_all["param_w"]["Stromkosten_4"]]
                      ])

# Berechnung der Spannweiten der einzelnen Attribute
dSpannw_kaufpreis = np.max(ndarray_A[0]) - np.min(ndarray_A[0])
dSpannw_ladedauer = np.max(ndarray_A[1]) - np.min(ndarray_A[1])
dSpannw_motorleistung = np.max(ndarray_A[2]) - np.min(ndarray_A[2])
dSpannw_reichweite = np.max(ndarray_A[3]) - np.min(ndarray_A[3])
dSpannw_stromkosten = np.max(ndarray_A[4]) - np.min(ndarray_A[4])

# Ausgabe der Spannweiten
print(dSpannw_kaufpreis)
print(dSpannw_ladedauer)
print(dSpannw_motorleistung)
print(dSpannw_reichweite)
print(dSpannw_stromkosten)

# Berechnung der Summe alle Spannweiten
dSpannw_summe = dSpannw_kaufpreis + dSpannw_ladedauer + dSpannw_motorleistung + dSpannw_reichweite + dSpannw_stromkosten
print(dSpannw_summe)

#%%
# Bestimmung der Bedeutungsgewichte (in %) aus den Spannweiten
dIW_kaufpreis = (round(100 * (dSpannw_kaufpreis / dSpannw_summe), 2))
dIW_ladedauer = (round(100 * (dSpannw_ladedauer / dSpannw_summe), 2))
dIW_motorleistung = (round(100 * (dSpannw_motorleistung / dSpannw_summe), 2))
dIW_reichweite = (round(100 * (dSpannw_reichweite / dSpannw_summe), 2))
dIW_stromkosten = (round(100 * (dSpannw_stromkosten / dSpannw_summe), 2))

# Ausgabe der Bedeutungsgewichte
print('Kaufpreis: ' + str(dIW_kaufpreis) + ' %')
print('Ladedauer: ' + str(dIW_ladedauer) + ' %')
print('Motorleistung: ' + str(dIW_motorleistung) + ' %')
print('Reichweite: ' + str(dIW_reichweite) + ' %')
print('Stromkosten: ' + str(dIW_stromkosten) + ' %')

#%% 

# Plotten der Bedeutungsgewichte als Saeulendiagramm
# Library matplotlib importieren
import matplotlib.pyplot as plt

# Saeulendiagramm erstellen
fig, ax = plt.subplots(figsize=(10,9)) 
BarChart = plt.bar(['Kaufpreis','Ladedauer','Motorleistung','Reichweite','Stromkosten'],
        [dIW_kaufpreis,dIW_ladedauer,dIW_motorleistung,dIW_reichweite,dIW_stromkosten])

plt.title('Bedeutungsgewichte')
y_value=['{:,.2f}'.format(x) + '%' for x in ax.get_yticks()]
ax.set_yticklabels(y_value)
       
for bar in BarChart:
        percentage = '{:.2f}%'.format(bar.get_height())
        x = bar.get_x() + bar.get_width() -0.57
        y = bar.get_y() + bar.get_height() +0.3
        ax.annotate(percentage, (x, y))

# Ausgabe des Saulendiagramms       
plt.show()
