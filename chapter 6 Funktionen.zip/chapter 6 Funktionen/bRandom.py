# Die Verwendung eines Moduls in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

from random import *
# Erstellen von Pseudozufallszahlen
for iIndex in range(0, 100):
    iRandom = randint(0, 10)
    if iRandom == 5:
        sOutput = 'In Runde' + ' ' + str(iIndex) + ' ' + 'wurde eine 5 gezogen'
        print(sOutput)