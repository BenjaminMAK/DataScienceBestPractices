# Die Verwendung von Funktionen in Python.
# @author: Benjamin  M. Abdel-Karim
# @since: 2020-04-24
# @version: 2020-04-24 V1

# Funktion zur Multiplikation einer Zahl mit sich selbst.
# @input: Ein int oder float
# @output: die Multiplikation
def fMultiplikator(dInput):
    if isinstance(dInput, float) or isinstance(dInput, int):
        dOutPut = dInput * dInput
        return dOutPut
    else:
        raise ValueError('Falscher Datentyp der Inputvariable')
    return dOutPut

dErgebnis = fMultiplikator(10)
print(dErgebnis)
