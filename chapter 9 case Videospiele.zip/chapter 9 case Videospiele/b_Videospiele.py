# Anwendungsbeispiel Videospiele
# @author: Benjamin M. Abdel-Karim
# @since: 2020-04-29
# @version: 2020-04-29 - V1
# Imports
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf
# -------------------------------
# Pre-Processing
# -------------------------------
# Datenimport
df = pd.read_csv('dataset_gamesales_final.csv', sep=',')

# Die ersten fuenf Zeilen anzeigen lassen.
print(df.head())

# Aufruf der Info-Funktion.
print(df.info())


# -------------------------------
# Explore the data
# -------------------------------
# Explore the data
print(df.describe())

# Fuer mehr Informationen auf der Konsole
with pd.option_context('display.max_columns', 11):
    print(df.describe())

# Pairplot
plt.figure()
sns.pairplot(df,  vars=['year', 'sales_EU', 'sales_USA', 'sales_JP',
                 'sales_GLOBAL', 'sales_OTHER'])
plt.tight_layout()
plt.savefig('Pairplot.png')
plt.show()


# --- Verkauefe pro Jahr --------
# Verkauefe pro Jahr mit Hilfe von Groupby
df_GroupYearSum = df.groupby(['year']).sum()

# Abbildung erstellen
fig, ax = plt.subplots()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Add counts above the two bar graphs
ax = sns.barplot(y=df_GroupYearSum['sales_GLOBAL'], x=df_GroupYearSum.index.astype(int), color='white', edgecolor='black')
ax.set_xlabel(xlabel='Jahr', fontsize=12)
ax.set_xticklabels(labels=df_GroupYearSum.index.astype(int), fontsize=12, rotation=45)
ax.set_ylabel(ylabel='Verkauefe', fontsize=12)
ax.set_title(label='Videospieleinnahmen in Millionen Dollar pro Jahr', fontsize=20)
fig.set_size_inches(12, 8, forward=True)
plt.savefig('YearAndSales.pdf', bbox_inches='tight')
plt.show()


# ----- Top-10 Publisher --------
# Erstellung eines neuen DataFrame durch groupby.
# Aus dem DataFrame ein SubDataFrame erstellen mit den ersten Zehn.
df_SalesByPublisher = df.groupby(['publisher']).sum()['sales_GLOBAL']
df_SalesByPublisherTopTen = pd.DataFrame(df_SalesByPublisher.sort_values(ascending=False))[0:10]

# Ploten der Informationen mit Hilfe eines
fig, ax = plt.subplots()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
LColors = reversed(sns.color_palette('Greys', len(df_SalesByPublisherTopTen)))
ax = sns.barplot(y=df_SalesByPublisherTopTen.index, x=df_SalesByPublisherTopTen['sales_GLOBAL'], data=df_SalesByPublisherTopTen, orient='h', palette=LColors)
ax.set_xlabel(xlabel='Einnahmen in  Millionen $', fontsize=12)
ax.set_ylabel(ylabel='Publisher', fontsize=12)
ax.set_title(label='Einnahmen der Top-10 Videospielerhersteller', fontsize=12)
ax.set_yticklabels(labels=df_SalesByPublisherTopTen.index, fontsize=12)
fig.set_size_inches(10, 5, forward=True)
plt.savefig('Top10Revenue.pdf', bbox_inches='tight')
plt.show()


# ----- Top-10 Games --------
# Top-10 Analyse fuer die Games.
df_SalesByGame = df.groupby(['game_name']).sum()['sales_GLOBAL']
df_SalesByGameTopTen = pd.DataFrame(df_SalesByGame.sort_values(ascending=False))[0:10]
print(df_SalesByGameTopTen)


# -------------------------------
# Model the data
# -------------------------------
# Erstellung des Models
sFormula = 'sales_EU ~ sales_GLOBAL'   # Blackbox
OLSModel = smf.ols(formula=sFormula, data=df).fit()
OLSModel.summary()
print(OLSModel.summary())
